# Transmission Status Widget

![Widget in action!](screenshot.png)

A widget to show current download status of Transmission torrents.

#### Requirements

- [`stig`](https://github.com/rndusr/stig): command line Transmission tool must be on your `$PATH`

To enable, place the `transmission-overview.widget` folder in your `Übersicht/widgets` directory.

Get more widgets at [Übersicht][1]!

[1]: http://tracesof.net/uebersicht-widgets/
